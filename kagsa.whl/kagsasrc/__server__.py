
import socket,re,json,os,mimetypes,io,sys
from datetime import datetime
from urllib.parse import unquote
from .lexer import main as Lexer
from .syntax_checker import main as Syntax_checker
from .parser import main as Parser
from .compiler import main as Compiler
from .errors import __init__ as errors

class StatusERR (Exception):
    pass

def raise_error_page(status):
    errors = {'100': 'Continue','101': 'Switching Protocols','102': 'Processing','103': 'Early Hints','200': 'OK','201': 'Created','202': 'Accepted','203': 'Non-Authoritative Information','204': 'No Content','205': 'Reset Content','206': 'Partial Content','207': 'Multi-Status','208': 'Already Reported','226': 'IM Used','300': 'Multiple Choices','301': 'Moved Permanently','302': 'Found','303': 'See Other','304': 'Not Modified','305': 'Use Proxy','307': 'Temporary Redirect','308': 'Permanent Redirect','400': 'Bad Request','401': 'Unauthorized','402': 'Payment Required','403': 'Forbidden','404': 'Not Found','405': 'Method Not Allowed','406': 'Not Acceptable','407': 'Proxy Authentication Required','408': 'Request Timeout','409': 'Conflict','410': 'Gone','411': 'Length Required','412': 'Precondition Failed','413': 'Payload Too Large','414': 'URI Too Long','415': 'Unsupported Media Type','416': 'Range Not Satisfiable','417': 'Expectation Failed','418': "I'm a Teapot",'421': 'Misdirected Request','422': 'Unprocessable Entity','423': 'Locked','424': 'Failed Dependency','425': 'Too Early','426': 'Upgrade Required','428': 'Precondition Required','429': 'Too Many Requests','431': 'Request Header Fields Too Large','451': 'Unavailable For Legal Reasons','500': 'Internal Server Error','501': 'Not Implemented','502': 'Bad Gateway','503': 'Service Unavailable','504': 'Gateway Timeout','505': 'HTTP Version Not Supported','506': 'Variant Also Negotiates','507': 'Insufficient Storage','508': 'Loop Detected','509': 'Bandwidth Limit Exceeded','510': 'Not Extended','511': 'Network Authentication Required'}
    if str(status) in errors:
        sys.exit(f'[RETURN_{str(status)}]')
    else:
        raise StatusERR(f'{str(status)} is not a vaild status')
    

def handleKAGSA (code,kg_file,request,response):
    code = code.replace(b'\r\n',b'\n').decode()
    MEMORY = {
        'R_e_s_p_o_n_s_e':response,
        'R_e_q_u_e_s_t':request,
        'M_I_M_E':mimetypes.types_map,
        'StatusERR':StatusERR,
        'r_a_i_s_e___e_r_r_o_r___p_a_g_e':raise_error_page
    }
    # Start Recording KAGSA Output
    buffer = io.StringIO()
    sys.stdout = buffer
    #
    error_in = None # used to catch the error
    try:
        error_in='Lexer'
        LEXER = Lexer(  code  )
        error_in='SyntaxChecker'
        SYNTAX = Syntax_checker(LEXER)
        error_in='Parser'
        PARSER = Parser(LEXER)
        error_in=None
    except Exception as ee:
        if ', line' in str(ee):
            line_no=int(re.findall(r', line (\d+)',str(ee))[0])
            line_text=open(kg_file,'r').read().split('\n')[line_no-1].strip()
        else:
            line_no = '?'
            line_text = '?'
        tb_type, tb_text, _ = errors(ee, lineno=str(line_no),get_value_back=1)

        print(f'error catched [ {error_in}/{kg_file}/{tb_type} ]')
        print(' ' + (' '* len(str(line_no))) + ' |')
        print(f' {line_no} | {line_text}')
        print(' ' + (' '* len(str(line_no))) + ' |')
        if '\n' in tb_text:
            print(f'error:', tb_text.split('\n')[0]) # error
            print(f'details:', '\n'.join(tb_text.split('\n')[1:])) # details
        else:
            print(f'error:', tb_text) # error
        printed_text = buffer.getvalue()
        sys.stdout = sys.__stdout__
        response.body = printed_text.encode()
        return response

    if error_in==None:
        try:
            Memory=Compiler(PARSER,kg_file,memory=MEMORY)
            printed_text = buffer.getvalue()
            sys.stdout = sys.__stdout__
        except SystemExit as ee:
            printed_text = str(ee)
        try:
            Response = Memory['R_e_s_p_o_n_s_e']
        except:
            Response = response
        Response.body = printed_text.replace('\x1b[1;31m','').replace('\x1b[0m','').replace('\x1b[0;36m','').replace('\x1b[0;33m','').encode()
        reg_search = re.findall(rb'\[RETURN_[0-9]{3}\]', Response.body)
        if len(reg_search) > 0 :
            if Response.body.endswith(reg_search[0]):
                status = re.findall(rb'\[RETURN_([0-9]{3})\]',Response.body)[0].decode()
                Response.s_t_a_t_u_s = int(status)
                #
                #
                if not(status in errors_pages):
                    sys.exit(f'error : {kg_file} : {status} is not a vaild status')
                if errors_pages[status]['file'] == 'html':
                    Response.h_e_a_d_e_r_s['Content-Type'] = 'text/html'
                    Response.body = errors_pages[status]['content']
                else:
                    pwd = os.getcwd()
                    try:os.chdir( main_pwd )
                    except:None
                    Response = handleKAGSA( errors_pages[status]['content'] , f'__{status}.kg' , request , Response )
                    os.chdir(pwd)
        return Response

def is_binary(file_name):
    try:
        with open(file_name, 'tr') as check_file:  # try open file in text mode
            check_file.read()
            return False
    except:  # if fail then file is non-text (binary)
        return True

def parseRequest (request):
    class Request:
        def __init__(self) -> None:
            self.h_e_a_d_e_r_s = {}
            self.d_a_t_a    = {}
            self.f_i_l_e_s   = {}
            self.a_r_g_s    = {}
            self.i_n_f_o    = {}
            self.b_o_d_y    = ''
        def __str__(self) -> str:
            return str( {'headers':self.h_e_a_d_e_r_s, 'data':self.d_a_t_a, 'files':self.f_i_l_e_s, 'args':self.a_r_g_s, 'info':self.i_n_f_o , 'body':self.b_o_d_y} )
    req = Request()
    groups = request.split(b'\r\n\r\n')
    group = groups[0]
    first_line  = group.split(b'\r\n')[0].decode().split(' ')
    #print(request)
    req.i_n_f_o['method'] = first_line[0]
    req.i_n_f_o['path'] = first_line[1]
    req.i_n_f_o['server'] = first_line[2]
    if '?' in req.i_n_f_o['path']:
        for param in req.i_n_f_o['path'].split('?')[1].split('&'):
            try:
                param = param.split('=')
                req.a_r_g_s[ unquote(param[0]) ] = unquote(param[1])
            except:None
    other_lines = group.decode().split('\r\n')[1:]
    for line in other_lines:
        line = line.split(': ')
        req.h_e_a_d_e_r_s[line[0]] = line[1]
    groups = b'\r\n\r\n'.join(groups[1:])
    req.b_o_d_y = groups
    #########################################################
    if 'Content-Type' in list(req.h_e_a_d_e_r_s.keys()):
        if 'application/x-www-form-urlencoded' in req.h_e_a_d_e_r_s['Content-Type']:
            try:
                params = groups.decode().replace('\n','').replace('\r','')
                for param in params.split('&'):
                    param = param.split('=')
                    req.d_a_t_a[ unquote(param[0]) ] = unquote(param[1])
            except:None
        elif 'multipart/form-data' in req.h_e_a_d_e_r_s['Content-Type']:
            formData = []
            formDataHandler = []
            for line in groups.split(b'\r\n'):
                if (len(re.findall(rb'\-\-[a-z0-9]{32}',line)) > 0 ) and (len(re.findall(rb'\-\-[a-z0-9]{32}\-\-',line)) == 0):
                    if len(formDataHandler) != 0 :
                        formData.append( formDataHandler )
                    formDataHandler = []
                elif len(re.findall(rb'\-\-[a-z0-9]{32}\-\-',line)) > 0:
                    if len(formDataHandler) != 0 :
                        formData.append( formDataHandler )
                    break
                else:
                    formDataHandler.append(line)
            for data in formData:
                name = ''
                values = []
                file = []
                first_space = 1
                is_file = 0
                for line in data:
                    if line.startswith(b'Content-Disposition:'):
                        for i in re.finditer(r'Content-Disposition: [a-z0-9\-]*; name="(?P<name>[^"]+)"(?:; filename="(?P<filename>[^"]+)")?',line.decode()):
                            name = i.group('name')
                            fn = i.group('filename')
                            if fn != None:
                                is_file = 1
                                values.append(fn)
                    elif line.startswith(b'Content-Type:'):
                        values.append( line.decode().split(': ')[1] )
                    elif line == '':
                        if first_space:
                            first_space = 0
                        else:
                            file.append(line)
                    else:
                        file.append(line)
                
                if is_file :
                    req.f_i_l_e_s[name] = [ b'\r\n'.join(file[1:]) , *values]
                else:
                    if len(values) != 0:
                        req.d_a_t_a[name] = [ b'\r\n'.join(file[1:]) , *values ]
                    else:
                        req.d_a_t_a[name] = b'\r\n'.join(file[1:])
        elif 'application/json' in req.h_e_a_d_e_r_s['Content-Type']:
            try:
                req.d_a_t_a = json.loads( groups )
            except:None

    return req

def handlePath (path,request):
    class Response:
        def __init__(self) -> None:
            self.s_t_a_t_u_s = 200
            self.h_e_a_d_e_r_s = {'Access-Control-Allow-Origin': '*','Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept'}
            self.body = b''
    response = Response()
    ###########################
    this_dir = os.listdir()
    if path == '/':
        if 'index.kg' in this_dir:
            path = 'index.kg'
        elif 'index.htm' in this_dir:
            path = 'index.htm'
        else:
            path = 'index.html'
    elif '?' in path:
        if path.split('?')[0] == '/':
            if 'index.kg' in this_dir:
                path = 'index.kg'
            elif 'index.htm' in this_dir:
                path = 'index.htm'
            else:
                path = 'index.html'
    if path.startswith('/'):
        path = path[1:]
    if '..' in path :
        response.s_t_a_t_u_s = 403
        if errors_pages['403']['file'] == 'html':
            response.h_e_a_d_e_r_s['Content-Type'] = 'text/html'
            response.body = errors_pages['403']['content']
        else:
            pwd = os.getcwd()
            try:os.chdir( os.path.dirname(path) )
            except:None
            response = handleKAGSA( errors_pages['403']['content'] , os.path.basename(path) , request , response )
            os.chdir(pwd)

        return response
    if os.path.isdir(path) :
        this_dir = os.listdir(path)
        if not(path.endswith('/')):
            path+='/'
        if 'index.kg' in this_dir:
            path += 'index.kg'
        elif 'index.htm' in this_dir:
            path += 'index.htm'
        elif 'index.html' in this_dir:
            path += 'index.html'
        else:
            response.s_t_a_t_u_s = 403
            if errors_pages['403']['file'] == 'html':
                response.h_e_a_d_e_r_s['Content-Type'] = 'text/html'
                response.body = errors_pages['403']['content']
            else:
                pwd = os.getcwd()
                try:os.chdir( os.path.dirname(path) )
                except:None
                response = handleKAGSA( errors_pages['403']['content'] , os.path.basename(path) , request , response )
                os.chdir(pwd)
            return response
    # Try to open the file
    try:
        file_ = open(path,'rb').read()
        if path.endswith('.kg'):
            pwd = os.getcwd()
            try:os.chdir( os.path.dirname(path) )
            except:None
            response = handleKAGSA( file_ , os.path.basename(path) , request , response )
            os.chdir(pwd)
        elif '.' in path:
            ext = '.' + path.split('.')[-1]
            if ext in mimetypes.types_map:
                response.s_t_a_t_u_s = 200
                response.h_e_a_d_e_r_s['Content-Type'] = mimetypes.types_map[ext]
                response.body = file_
            else:
                response.s_t_a_t_u_s = 200
                response.h_e_a_d_e_r_s['Content-Type'] = 'application/octet-stream'
                response.body = file_
        else:
            if is_binary(path):
                response.s_t_a_t_u_s = 200
                response.h_e_a_d_e_r_s['Content-Type'] = 'application/octet-stream'
                response.body = file_
            else:
                response.s_t_a_t_u_s = 200
                response.h_e_a_d_e_r_s['Content-Type'] = 'text/plain'
                response.body = file_
    except SystemExit as ee:
        sys.exit(ee)
    except:
        response.s_t_a_t_u_s = 404
        if errors_pages['404']['file'] == 'html':
            response.h_e_a_d_e_r_s['Content-Type'] = 'text/html'
            response.body = errors_pages['404']['content']
        else:
            pwd = os.getcwd()
            try:os.chdir( os.path.dirname(path) )
            except:None
            response = handleKAGSA( errors_pages['404']['content'] , os.path.basename(path) , request , response )
            os.chdir(pwd)
    return response



def Server (data):
    global main_pwd,this_dir,error,errors_pages
    main_pwd = os.getcwd()
    this_dir = os.listdir()
    errors = {'100': 'Continue','101': 'Switching Protocols','102': 'Processing','103': 'Early Hints','200': 'OK','201': 'Created','202': 'Accepted','203': 'Non-Authoritative Information','204': 'No Content','205': 'Reset Content','206': 'Partial Content','207': 'Multi-Status','208': 'Already Reported','226': 'IM Used','300': 'Multiple Choices','301': 'Moved Permanently','302': 'Found','303': 'See Other','304': 'Not Modified','305': 'Use Proxy','307': 'Temporary Redirect','308': 'Permanent Redirect','400': 'Bad Request','401': 'Unauthorized','402': 'Payment Required','403': 'Forbidden','404': 'Not Found','405': 'Method Not Allowed','406': 'Not Acceptable','407': 'Proxy Authentication Required','408': 'Request Timeout','409': 'Conflict','410': 'Gone','411': 'Length Required','412': 'Precondition Failed','413': 'Payload Too Large','414': 'URI Too Long','415': 'Unsupported Media Type','416': 'Range Not Satisfiable','417': 'Expectation Failed','418': "I'm a Teapot",'421': 'Misdirected Request','422': 'Unprocessable Entity','423': 'Locked','424': 'Failed Dependency','425': 'Too Early','426': 'Upgrade Required','428': 'Precondition Required','429': 'Too Many Requests','431': 'Request Header Fields Too Large','451': 'Unavailable For Legal Reasons','500': 'Internal Server Error','501': 'Not Implemented','502': 'Bad Gateway','503': 'Service Unavailable','504': 'Gateway Timeout','505': 'HTTP Version Not Supported','506': 'Variant Also Negotiates','507': 'Insufficient Storage','508': 'Loop Detected','509': 'Bandwidth Limit Exceeded','510': 'Not Extended','511': 'Network Authentication Required'}
    errors_pages = {}
    for error in list(errors.keys()):
        if f'__{error}.kg' in this_dir:
            f = open(f'__{error}.kg','rb')
            content = f.read()
            f.close()
            errors_pages[error] = {'file':'kagsa',  'content':content}
        elif f'__{error}.html' in this_dir:
            f = open(f'__{error}.html','rb')
            content = f.read()
            f.close()
            errors_pages[error] = {'file':'html',  'content':content}
        elif f'__{error}.htm' in this_dir:
            f = open(f'__{error}.htm','rb')
            content = f.read()
            f.close()
            errors_pages[error] = {'file':'html',  'content':content}
        else:
            errors_pages[error] = {'file':'html', 'content': f'<h1>Error {error}</h1><hr><p>{errors[error]}</p>'.encode()}
    # Define socket host and port
    if len(data) == 1:
        SERVER_HOST = '127.0.0.1'
        SERVER_PORT = int(data[0])
    else:
        SERVER_HOST = data[0]
        SERVER_PORT = int(data[1])

    # Create socket
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((SERVER_HOST, SERVER_PORT))
        server_socket.listen(1)
    except:
        sys.exit('error : server : check your ip or port')
    print(f'KAGSA Server is running on {SERVER_HOST}:{SERVER_PORT}/ ..\n')


    while True:    
        try:
            # Wait for client connections
            client_connection, client_address = server_socket.accept()

            # Get the client request
            request = client_connection.recv(1024 * 1000000)#.decode()
            if request != b'':
                now = datetime.now()
                Request = parseRequest(request)

                # Printing the Request
                info = Request.i_n_f_o['method'] + ' ' + Request.i_n_f_o['server'] + ' ' + Request.i_n_f_o['path']
                print(Request.h_e_a_d_e_r_s['Host'], '-' ,now.strftime('[ %d/%m/%Y %H:%M:%S ]') , '-', info)

                Response = handlePath( Request.i_n_f_o['path'] , Request )
                # Start Creating the Response
                response = 'HTTP/1.0 '
                if str(Response.s_t_a_t_u_s) in errors:
                    response += f'{Response.s_t_a_t_u_s} {errors[str(Response.s_t_a_t_u_s)].upper()}'
                else:
                    response += f'{Response.s_t_a_t_u_s} UNKNOWN'
                # Adding Response Headers
                for k,v in Response.h_e_a_d_e_r_s.items():
                    response += f'\n{k}: {v}'
                response += '\n\n'
                ## Adding the body
                try: response = response.encode() + Response.body
                except: response = response.encode() + Response.body.encode()
                # Send HTTP response
                client_connection.sendall(response)#.encode())
            else:
                client_connection.sendall(b'')
            client_connection.close()
        except KeyboardInterrupt:
            break
        except EOFError:
            break

    # Close socket
    server_socket.close()
    sys.exit(1)