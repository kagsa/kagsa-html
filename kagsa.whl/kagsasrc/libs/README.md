# KAGSA Libs Folder
This folder will contain all the libraries ( .KGL ) that you will setup.