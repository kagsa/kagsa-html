from .lexer import main as lexer
from .syntax_checker import main as syntax_checker
from .parser import main as parser
from .compiler import main as compiler
from .methods import *