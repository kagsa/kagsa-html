# KAGSA Temp Folder
This folder will contain temporary files from your .KGL libraries that you include.
Feel free to delete them.