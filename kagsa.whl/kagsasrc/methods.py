import threading,forbiddenfruit,re


def SetMethod (datatypes, name, func):
    for datatype in datatypes:
        forbiddenfruit.curse(datatype,name,func)

#=======================================
#          Some Function
#=======================================
def t_o_I_n_t (value):
    try:    return int(value)
    except: raise ValueError(f'can\'t convert ({value}) to integer')
def t_o_S_t_r (value):
    try :  return str(value)
    except: raise ValueError(f'can\'t convert ({value}) to string')
def t_o_F_l_o_a_t (value):
    try:  return float(value)
    except: raise ValueError(f'can\'t convert ({value}) to float')
def i_s_I_n_t (value):
    if value.__class__.__name__ == 'int':
        return 1
    else:
        return 0
def i_s_S_t_r (value):
    if value.__class__.__name__ == 'str':
        return 1
    else:
        return 0
def i_s_B_y_t_e_s (value):
    if value.__class__.__name__ == 'bytes':
        return 1
    else:
        return 0
def i_s_F_l_o_a_t (value):
    if value.__class__.__name__ == 'float':
        return 1
    else:
        return 0

def i_s_L_i_s_t (value):
    if value.__class__.__name__ == 'list':
        return 1
    else:
        return 0

def i_s_D_i_c_t (value):
    if value.__class__.__name__ == 'dict':
        return 1
    else:
        return 0

def n_l_i_s_t (num, z_e_r_o=True):
    if z_e_r_o:
        return list(range(0,num+1))
    else:
        return list(range(1,num+1))

def k_g_i_d (id):
    if len(re.findall(r'[a-zA-Z0-9][a-zA-Z0-9]',id)) > 0:
        if id == '__init__' : return '@constructor'
        if id == '__str__' : return '@string'
        if id == '__repr__' : return '@repr'
        if id == 'self' : return '@this'
        return ''
    id = id.replace('أ',"@").replace('ب',"$").replace('ت','^').replace('ث','~').replace('ج','?')
    if len(id)>=2:
        if id[0:2] in ['_1','_2','_3','_4','_5','_6','_7','_8','_9','_0']:
            id = id[1:]
        id = ''.join(id.replace('__','ظ').split('_')).replace('ظ','_')
    return id


def d_i_r (data):
    lst = []
    if len(data) > 0 :
        dd = dir(data[0])
    else:
        dd = list(globals().keys())
    #print(dir(data))
    for id in dd:
        o = k_g_i_d(id)
        if o != '':
            lst.append(o)
    return lst

#=======================================
#           Some Variable
#=======================================

n_l = '\n'
n_o_n_e = None
n_o_t = lambda co:not(co)


#=======================================
#               Methods
#=======================================

def e_n_c_o_d_e (DATA,TYPE):
    if 'str' == DATA.__class__.__name__:
        return DATA.encode(TYPE)
    else:
        raise ValueError('encode( type ) function take only string value')
def d_e_c_o_d_e (DATA,TYPE):
    if 'str' == DATA.__class__.__name__:
        return DATA.decode(TYPE)
    else:
        raise ValueError('decode( type ) function take only string value')
def r_e_p_l_a_c_e (DATA,v1,v2):
    if 'str' == DATA.__class__.__name__:
        return DATA.replace(v1,v2)
    else:
        raise ValueError('replace( src , dst) function take only string value')
def s_p_l_i_t (DATA,value):
    if ('str' == DATA.__class__.__name__):
        return DATA.split(value)
    else:
        raise ValueError('split( val ) function take only string value')
def e_n_d (DATA,value):
    if ('str' == DATA.__class__.__name__):
        return DATA.endswith(value)
    else:
        raise ValueError('end( str ) function take only string value')
def s_t_a_r_t (DATA,value):
    if ('str' == DATA.__class__.__name__):
        return DATA.startswith(value)
    else:
        raise ValueError('start( str ) function take only string value')
def s_e_a_r_c_h (DATA,value):
    if ('str' == DATA.__class__.__name__):
        return DATA.find(value)
    else:
        raise ValueError('search( str ) function take only string value')
def u_p_c_a_s_e (DATA):
    if ('str' == DATA.__class__.__name__):
        return DATA.upper()
    else:
        raise ValueError('upcase() function take only string value')
def d_o_w_n_c_a_s_e (DATA):
    if ('str' == DATA.__class__.__name__):
        return DATA.lower()
    else:
        raise ValueError('downcase() function take only string value')
def s_t_r_i_p (DATA):
    if ('str' in DATA.__class__.__name__):
        return DATA.strip()
    else:
        raise ValueError('delspace() function take only string value')
def r_e_v_e_r_s_e (DATA):
    if ('str' == DATA.__class__.__name__) or ('list' == DATA.__class__.__name__): 
        return DATA[::-1]
    else:
        ValueError('reverse() function take only string & list value')


# List Function
def l_i_s_t (*arg):
    d = []
    for i in arg: d.append(i)
    return d
# LIST, DICT, STR
def l_e_n_g_t_h (DATA):
    if ('dict' == DATA.__class__.__name__) or ('list' == DATA.__class__.__name__) or ('str' == DATA.__class__.__name__):
        return len(DATA)
    else:
        raise ValueError('length() function take only string & list & dict value')
# LIST, DICT, STR
def g_e_t (DATA,*value):
    if (('list' == DATA.__class__.__name__)) or (('dict' == DATA.__class__.__name__)) or ('str' == DATA.__class__.__name__) :
        if len(value)>1:
            if 'dict' == DATA.__class__.__name__: raise ValueError('"get(VAR , value)" function take only (list, str) value')
            return DATA[value[0]:value[1]]
        else:
            return DATA[value[0]]
    else:
        raise ValueError('get( *value ) function take only string & list & dict value')
# LIST, DICT
def a_p_p_e_n_d (DATA,*arguments):
    if 'list' == DATA.__class__.__name__:
        for i in arguments :
            DATA.append(i)
    elif 'dict' == DATA.__class__.__name__:
        DATA[arguments[0]]=arguments[1]
    else:
        raise ValueError('append( value ) function take only list & dict value')
# LIST, DICT
def c_l_e_a_r (DATA):
    if (('list' == DATA.__class__.__name__)) or (('dict' in DATA.__class__.__name__)):
        DATA.clear()
        return 1
    else:
        raise ValueError('clear() function take only list & dict value')
# LIST, DICT
def d_e_l_e_t_e (DATA,value,i_d_x=False):
    if ('list' == DATA.__class__.__name__):
        if i_d_x and (i_s_I_n_t(value)):
            DATA.pop(value)
        elif i_d_x==False:
            DATA.remove(value)
        else:
            raise ValueError('delete( value, idx = bool ) if idx == true -> value must be int')
    elif (('dict' == DATA.__class__.__name__)):
        DATA.pop(value)
    else:
        raise ValueError('delete( value, idx = bool ) function take only list & dict value')
    return 1
# LIST, DICT
def a_d_d (DATA,pos,value):
    if (('list' == DATA.__class__.__name__)):
        if not(i_s_I_n_t(pos)):
            raise ValueError('add( pos, val ) pos must be int')
        DATA.insert(pos,value)
    elif (('dict' == DATA.__class__.__name__)):
        DATA[pos]=value
    else:
        raise ValueError('add( pos , val ) function take only list & dict value')
    return 1
# LIST
def i_n_d_e_x (DATA,value):
    if (('list' == DATA.__class__.__name__)):
        return DATA.index(value)
    else:
        raise ValueError('index( value ) function take only list value')
# LIST
def a_p_p_l_i_s_t (DATA,value):
    if ('list' == DATA.__class__.__name__) and ('list' == value.__class__.__name__):
        DATA.extend(value)
    else:
        raise ValueError('applist( value ) function take only list values')
    return 1
# LIST, STR
def c_o_u_n_t (DATA,value):
    if (('list' == DATA.__class__.__name__)) or (('str' == DATA.__class__.__name__)):
        return DATA.count(value)
    else:
        raise ValueError('count( value ) function take only list value')
# LIST
def j_o_i_n (DATA,value):
    if (('list' == DATA.__class__.__name__)):
        return value.join(DATA)
    else:
        raise ValueError('join( value ) function take only list value')

def s_o_r_t_e_d (DATA):
    if ('list' == DATA.__class__.__name__):
        return sorted(DATA)
    else:
        raise ValueError('join( value ) function take only list value')

# Dict Function
def d_i_c_t (**arg):
    dct={}
    for i in arg:
        text=i.replace('__','$').replace('_','').replace('$','_')
        dct[text]=arg[i]
    return dct
# DICT
def k_e_y_s (DATA):
    if (('dict' in DATA.__class__.__name__)):
        return list(DATA.keys())
    else:
       raise ValueError('keys() function take only dict values')
# DICT
def v_a_l_u_e_s (DATA):
    if (('dict' in DATA.__class__.__name__)):
        return list(DATA.values())
    else:
        raise ValueError('values() function take only dict values')

def buildMethods ():
    SetMethod([str],'r_e_p_l_a_c_e',r_e_p_l_a_c_e)
    SetMethod([str],'s_p_l_i_t',s_p_l_i_t)
    SetMethod([str],'e_n_d',e_n_d)
    SetMethod([str],'s_t_a_r_t',s_t_a_r_t)
    SetMethod([str],'s_e_a_r_c_h',s_e_a_r_c_h)
    SetMethod([str],'u_p_c_a_s_e',u_p_c_a_s_e)
    SetMethod([str],'d_o_w_n_c_a_s_e',d_o_w_n_c_a_s_e)
    SetMethod([str],'s_t_r_i_p',s_t_r_i_p)
    SetMethod([str],'e_n_c_o_d_e',e_n_c_o_d_e)
    SetMethod([bytes],'d_e_c_o_d_e',d_e_c_o_d_e)
    SetMethod([str,list,dict],'l_e_n_g_t_h',l_e_n_g_t_h)
    SetMethod([str,list],'r_e_v_e_r_s_e',r_e_v_e_r_s_e)
    SetMethod([str,list,dict],'g_e_t',g_e_t)
    SetMethod([list,dict],'a_p_p_e_n_d',a_p_p_e_n_d)
    SetMethod([list,dict],'c_l_e_a_r',c_l_e_a_r)
    SetMethod([list,dict],'d_e_l_e_t_e',d_e_l_e_t_e)
    SetMethod([list,dict],'a_d_d',a_d_d)
    SetMethod([list],'i_n_d_e_x',i_n_d_e_x)
    SetMethod([list],'a_p_p_l_i_s_t',a_p_p_l_i_s_t)
    SetMethod([list],'j_o_i_n',j_o_i_n)
    SetMethod([list],'s_o_r_t_e_d',s_o_r_t_e_d)
    SetMethod([str,list],'c_o_u_n_t',c_o_u_n_t)
    SetMethod([dict],'k_e_y_s',k_e_y_s)
    SetMethod([dict],'v_a_l_u_e_s',v_a_l_u_e_s)
    #SetMethod([str],'',)
threading.Thread(target=buildMethods).start()

#=======================================
#               ERRORS
#=======================================

def A_s_s_e_r_t_i_o_n_E_R_R (text):
    raise AssertionError(text)
def A_t_t_r_i_b_u_t_e_E_R_R (text):
    raise AttributeError(text)
def E_O_F_E_R_R (text):
    raise EOFError(text)
def F_l_o_a_t_i_n_g_P_o_i_n_t_E_R_R (text):
    raise FloatingPointError(text)
def G_e_n_e_r_a_t_o_r_E_x_i_t (text):
    raise GeneratorExit(text)
def I_m_p_o_r_t_E_R_R (text):
    raise ImportError(text)
def I_n_d_e_x_E_R_R (text):
    raise IndexError(text)
def K_e_y_E_R_R (text):
    raise KeyError(text)
def K_e_y_b_o_a_r_d_I_n_t_e_r_r_u_p_t (text):
    raise KeyboardInterrupt(text)
def M_e_m_o_r_y_E_R_R (text):
    raise MemoryError(text)
def N_a_m_e_E_R_R (text):
    raise NameError(text)
def N_o_t_I_m_p_l_e_m_e_n_t_e_d_E_R_R (text):
    raise NotImplementedError(text)
def O_S_E_R_R (text):
    raise OSError(text)
def O_v_e_r_f_l_o_w_E_R_R (text):
    raise OverflowError(text)
def R_e_f_e_r_e_n_c_e_E_R_R (text):
    raise ReferenceError(text)
def R_u_n_t_i_m_e_E_R_R (text):
    raise RuntimeError(text)
def S_t_o_p_I_t_e_r_a_t_i_o_n (text):
    raise StopIteration(text)
def S_y_n_t_a_x_E_R_R (text):
    raise SyntaxError(text)
def I_n_d_e_n_t_a_t_i_o_n_E_R_R (text):
    raise IndentationError(text)
def T_a_b_E_R_R (text):
    raise TabError(text)
def S_y_s_t_e_m_E_R_R (text):
    raise SystemError(text)
def S_y_s_t_e_m_E_x_i_t (text):
    raise SystemExit(text)
def T_y_p_e_E_R_R (text):
    raise TypeError(text)
def U_n_b_o_u_n_d_L_o_c_a_l_E_R_R (text):
    raise UnboundLocalError(text)
def U_n_i_c_o_d_e_E_R_R (text):
    raise UnicodeError(text)
def U_n_i_c_o_d_e_E_n_c_o_d_e_E_R_R (text):
    raise UnicodeEncodeError(text)
def U_n_i_c_o_d_e_D_e_c_o_d_e_E_R_R (text):
    raise UnicodeDecodeError(text)
def U_n_i_c_o_d_e_T_r_a_n_s_l_a_t_e_E_R_R (text):
    raise UnicodeTranslateError(text)
def V_a_l_u_e_E_R_R (text):
    raise ValueError(text)
def Z_e_r_o_D_i_v_i_s_i_o_n_E_R_R (text):
    raise ZeroDivisionError(text)
def N_e_w_E_R_R (name):
    ss={}
    exec(f'class {name} (Exception):\n\tpass\ndef rrr (text):\n\traise {name}(text)',ss)
    return ss['rrr']